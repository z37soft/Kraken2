//
//  TL_UIKitManager.h
//  TL_UIKit
//
//  Created by Nozomu MIURA on 13/04/18.
//  Copyright (c) 2013年 techlife Pte.Ltd. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@class TL_UIKitRichView;


@interface TL_UIKitManager : NSObject
{
	NSMutableDictionary*	m_CacheImages;
	
	float					m_BaseColor[3];
	
@public
	NSImage*			SkinImage;
	NSColor*			ThemaColor;
	NSColor*			BkRichColor;
	NSColor*			BkSimpleColor;
}

+(TL_UIKitManager*)SharedUIKit;
+(TL_UIKitManager*)SharedUIKitBySkinResource:(NSString*)resource;

- (id)initWithSkinResource:(NSString*)resource;

+(NSImage*)queryImage:(NSRect)rect Source:(NSImage*)src;
+(NSImage*)queryImageFlipped:(NSRect)rect Source:(NSImage*)src;
+(NSImage*)makeImageBy9Slice:(NSSize)dstsize SliceArea:(NSRect)sourcerect SourceImage:(NSImage*)srcimg;
+(NSImage*)makeImageBy9SliceExt:(NSSize)dstsize SliceArea:(NSRect)sourcerect SourceImage:(NSImage*)srcimg FixedSize:(float)fixedsize;
+(NSImage*)makeImageBy9SliceExt2:(NSSize)dstsize SliceArea:(NSRect)sourcerect SourceImage:(NSImage*)srcimg FixedSizeX:(float)fixedsizeX FixedSizeY:(float)fixedsizeY;

//-------------------

-(void)SetThemaColorRed:(float)r Green:(float)g Blue:(float)b;

-(NSImage*)QueryImageCategory:(NSString*)category Size:(NSSize)sz;
-(NSImage*)RegisterImageCategory:(NSString*)category Image:(NSImage*)img;

-(float*)GetBaseColor;

@end

extern TL_UIKitManager*	gTL_UIKitManager;
