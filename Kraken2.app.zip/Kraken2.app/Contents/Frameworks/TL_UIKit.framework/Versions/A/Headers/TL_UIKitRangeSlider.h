//
//  TL_UIKitRangeSlider.h
//  TL_UIKit
//
//  Created by Nozomu MIURA on 2013/05/04.
//  Copyright (c) 2013年 techlife Pte.Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

#define TL_UIKitRangeSlider_AXIS_OFFSET					(2)

@interface TL_UIKitRangeSlider : NSView {    
	float                   m_KnobFixSize;
	NSSize                  m_KnobSize;
	NSSize                  m_BodySize;
    NSRect                  m_KnobArea;

	float					m_MinValue;
	float					m_MaxValue;
	float					m_CurrentValue[2];
		
	NSPoint					m_DraggingOffset;
	int						m_Dragging;
	
	NSImage*				m_BkImage;
    
    int                     m_AxisDivNum;
    
	id						m_Target;
	SEL						m_Selector[2];
    
	BOOL					m_Enabled;
}

-(void)setTarget:(id)tar MinAction:(SEL)sel;
-(void)setTarget:(id)tar MaxAction:(SEL)sel;

-(void)setLowValue:(double)rate;
-(float)getLowValue;

-(void)setHighValue:(double)rate;
-(float)getHighValue;

-(BOOL)isEnabled;
-(void)setEnabled:(BOOL)status;

@end
